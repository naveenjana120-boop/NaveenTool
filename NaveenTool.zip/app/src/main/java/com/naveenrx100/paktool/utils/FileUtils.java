package com.naveenrx100.paktool.utils;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** General file utilities. CREDIT: @NaveenRx100 */
public final class FileUtils {

    private FileUtils() {}

    /** Human-readable file size (mirrors Python human_size()). */
    public static String humanSize(long size) {
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        double d = size;
        for (String u : units) {
            if (d < 1024.0) return String.format("%.2f %s", d, u);
            d /= 1024.0;
        }
        return String.format("%.2f PB", d);
    }

    /** Get display filename from a SAF Uri. */
    public static String getFileName(Context ctx, Uri uri) {
        try (Cursor c = ctx.getContentResolver().query(
                uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) {}
        return uri.getLastPathSegment();
    }

    /** Copy a SAF Uri to a File. */
    public static void copyUriToFile(Context ctx, Uri uri, File dest) throws IOException {
        dest.getParentFile().mkdirs();
        try (InputStream in  = ctx.getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(dest)) {
            if (in == null) throw new IOException("Cannot open Uri");
            byte[] buf = new byte[65536]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    /** Copy a File to another File. */
    public static void copyFile(File src, File dst) throws IOException {
        dst.getParentFile().mkdirs();
        try (FileInputStream in  = new FileInputStream(src);
             FileOutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[65536]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    /** Read entire file into byte array. */
    public static byte[] readAllBytes(File f) throws IOException {
        try (FileInputStream fis = new FileInputStream(f)) {
            byte[] data = new byte[(int) f.length()];
            int read = 0;
            while (read < data.length) {
                int r = fis.read(data, read, data.length - read);
                if (r < 0) break;
                read += r;
            }
            return data;
        }
    }

    /** Write byte array to file. */
    public static void writeAllBytes(File f, byte[] data) throws IOException {
        f.getParentFile().mkdirs();
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write(data);
        }
    }
}
