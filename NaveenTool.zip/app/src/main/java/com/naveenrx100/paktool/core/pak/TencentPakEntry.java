package com.naveenrx100.paktool.core.pak;

import com.naveenrx100.paktool.core.crypto.PakCrypto;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * TencentPakEntry — one file entry in a PAK archive's index section.
 *
 * CREDIT: @NaveenRx100
 *
 * Mirrors Python class TencentPakEntry.
 *
 * Binary layout inside the index (version dependent):
 *   content_hash          20 bytes
 *   [v≤1] skip            8  bytes
 *   offset                8  bytes
 *   uncompressed_size     8  bytes
 *   compression_method    4  bytes   (& CM_MASK = 0x0F gives actual method)
 *   size                  8  bytes
 *   [v≥5] unk1            1  byte
 *   [v≥5] unk2            20 bytes
 *   [compressed && v≥3] num_blocks  4 bytes → blocks[i]: start(8) end(8)
 *   [v≥4] compression_block_size   4 bytes
 *   [v≥4] encrypted                1 byte
 *   [v≥12] encryption_method       4 bytes
 *   [v≥12] index_new_sep           4 bytes
 */
public class TencentPakEntry {

    public byte[]                  contentHash;       // SHA-1, 20 bytes
    public long                    offset;            // absolute byte offset in PAK file
    public long                    uncompressedSize;
    public int                     compressionMethod; // already masked with CM_MASK
    public long                    size;              // stored (possibly compressed/encrypted) size
    public int                     unk1;              // v≥5
    public byte[]                  unk2;              // v≥5, 20 bytes
    public List<long[]>            compressedBlocks;  // each element: [start, end]
    public int                     compressionBlockSize; // v≥4
    public boolean                 encrypted;         // v≥4
    public int                     encryptionMethod;  // v≥12
    public int                     indexNewSep;       // v≥12

    /** Logical path inside the PAK index (set by TencentPakFile after parsing dirs). */
    public String dirPath  = "";
    public String fileName = "";

    public TencentPakEntry() {
        this.contentHash      = new byte[20];
        this.unk2             = new byte[20];
        this.compressedBlocks = new ArrayList<>();
    }

    // ── Parse from ByteBuffer ─────────────────────────────────────────

    /**
     * Read one entry from a ByteBuffer positioned at the start of an entry.
     * The buffer must be LE-ordered.
     */
    public static TencentPakEntry read(ByteBuffer buf, int version) {
        TencentPakEntry e = new TencentPakEntry();

        e.contentHash = new byte[20];
        buf.get(e.contentHash);

        if (version <= 1) buf.getLong(); // skip

        e.offset             = buf.getLong();
        e.uncompressedSize   = buf.getLong();
        e.compressionMethod  = buf.getInt() & PakCrypto.CM_MASK;
        e.size               = buf.getLong();

        if (version >= 5) {
            e.unk1 = buf.get() & 0xFF;
            e.unk2 = new byte[20];
            buf.get(e.unk2);
        } else {
            e.unk1 = 0;
            e.unk2 = new byte[20];
        }

        if (e.compressionMethod != PakCrypto.CM_NONE && version >= 3) {
            int numBlocks = buf.getInt();
            e.compressedBlocks = new ArrayList<>(numBlocks);
            for (int i = 0; i < numBlocks; i++) {
                long start = buf.getLong();
                long end   = buf.getLong();
                e.compressedBlocks.add(new long[]{start, end});
            }
        } else {
            e.compressedBlocks = new ArrayList<>();
        }

        if (version >= 4) {
            e.compressionBlockSize = buf.getInt();
            e.encrypted            = (buf.get() & 0xFF) == 1;
        } else {
            e.compressionBlockSize = 0;
            e.encrypted            = false;
        }

        if (version >= 12) {
            e.encryptionMethod = buf.getInt();
            e.indexNewSep      = buf.getInt();
        } else {
            e.encryptionMethod = 0;
            e.indexNewSep      = 0;
        }

        return e;
    }

    // ── Serialize to bytes ────────────────────────────────────────────

    /**
     * Write this entry into a byte array (for building new index section).
     */
    public byte[] toBytes(int version) {
        // Compute the size dynamically
        int sz = 20;                              // content_hash
        if (version <= 1) sz += 8;               // skip
        sz += 8 + 8 + 4 + 8;                     // offset, uncomp_size, comp_method, size
        if (version >= 5) sz += 1 + 20;          // unk1, unk2
        if (compressionMethod != PakCrypto.CM_NONE && version >= 3) {
            sz += 4 + compressedBlocks.size() * 16;
        }
        if (version >= 4) sz += 4 + 1;           // block_size, encrypted
        if (version >= 12) sz += 4 + 4;          // enc_method, index_new_sep

        ByteBuffer buf = ByteBuffer.allocate(sz).order(ByteOrder.LITTLE_ENDIAN);

        buf.put(contentHash);
        if (version <= 1) buf.putLong(0);
        buf.putLong(offset);
        buf.putLong(uncompressedSize);
        buf.putInt(compressionMethod & PakCrypto.CM_MASK);
        buf.putLong(size);
        if (version >= 5) {
            buf.put((byte)(unk1 & 0xFF));
            buf.put(unk2 != null && unk2.length == 20 ? unk2 : new byte[20]);
        }
        if (compressionMethod != PakCrypto.CM_NONE && version >= 3) {
            buf.putInt(compressedBlocks.size());
            for (long[] blk : compressedBlocks) {
                buf.putLong(blk[0]);
                buf.putLong(blk[1]);
            }
        }
        if (version >= 4) {
            buf.putInt(compressionBlockSize);
            buf.put((byte)(encrypted ? 1 : 0));
        }
        if (version >= 12) {
            buf.putInt(encryptionMethod);
            buf.putInt(indexNewSep);
        }

        return buf.array();
    }

    /** Full PAK path as a forward-slash string, e.g. "Engine/Content/foo.lua" */
    public String fullPath() {
        if (dirPath == null || dirPath.isEmpty() || dirPath.equals(".")) return fileName;
        return dirPath.replace('\\', '/').replaceAll("/$", "") + "/" + fileName;
    }
}
