package com.naveenrx100.paktool.core.pak;

import android.util.Log;

import com.github.luben.zstd.ZstdInputStream;
import com.github.luben.zstd.ZstdDecompressCtx;
import com.github.luben.zstd.ZstdCompressCtx;
import com.github.luben.zstd.ZstdDictDecompress;
import com.naveenrx100.paktool.core.crypto.PakCrypto;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/**
 * TencentPakFile — Android port of Python TencentPakFile.
 *
 * CREDIT: @NaveenRx100
 *
 * Core operations:
 *  • Open + parse a .pak file (footer + index decryption)
 *  • Extract all files to a directory (with block permutation + decrypt + decompress)
 *  • Inject / repack files (compress + encrypt + permute + rebuild index + write footer)
 *  • Build a brand-new PAK from a folder
 *  • Detect dominant compression/encryption style
 */
public class TencentPakFile {

    private static final String TAG = "TencentPakFile";

    // ── PAK magic ────────────────────────────────────────────────────
    public static final long PAK_MAGIC_V11 = 0x5A6F12E1L;  // Tencent version 11+

    // ── File content ─────────────────────────────────────────────────
    private final File       filePath;
    private       byte[]     fileContent;   // entire file in RAM (acceptable for ≤ 100 MB PAKs)

    // ── Parsed structures ─────────────────────────────────────────────
    private TencentPakInfo pakInfo;
    private List<TencentPakEntry>               files;
    /** index: dir-path (posix) → { fileName → entry } */
    private Map<String, Map<String, TencentPakEntry>> index;

    /** For ZSTD_DICT files, the decompression dictionary */
    private byte[] zstdDict = null;

    /** Progress callback interface */
    public interface ProgressCallback {
        void onProgress(int current, int total, String message);
        void onLog(String message);
    }

    // ════════════════════════════════════════════════════════════════════
    // Constructor — open and parse
    // ════════════════════════════════════════════════════════════════════

    public TencentPakFile(File pakFile) throws IOException {
        this.filePath = pakFile;
        load();
    }

    private void load() throws IOException {
        // Read the entire file
        fileContent = readAllBytes(filePath);

        long[] keystream = PakCrypto.zucKeystream();
        pakInfo = new TencentPakInfo(fileContent, keystream);

        // Validate magic
        if (pakInfo.magic != PAK_MAGIC_V11) {
            Log.w(TAG, "Unexpected PAK magic: 0x" + Long.toHexString(pakInfo.magic));
        }

        loadIndex();
    }

    // ════════════════════════════════════════════════════════════════════
    // Index loading
    // ════════════════════════════════════════════════════════════════════

    private void loadIndex() throws IOException {
        // Slice out the raw index bytes
        long idxOff  = pakInfo.indexOffset;
        long idxSize = pakInfo.indexSize;

        if (idxOff < 0 || idxOff + idxSize > fileContent.length)
            throw new IOException("Invalid index offset/size in PAK footer");

        byte[] rawIndex = Arrays.copyOfRange(fileContent, (int) idxOff, (int)(idxOff + idxSize));

        // Decrypt if needed
        byte[] indexData;
        if (pakInfo.indexEncrypted) {
            indexData = PakCrypto.decryptIndex(rawIndex, pakInfo.version, true,
                    pakInfo.packedKey.length == 256 ? pakInfo.packedKey : null,
                    pakInfo.packedIv.length  == 256 ? pakInfo.packedIv  : null);
        } else {
            indexData = rawIndex;
        }

        parseIndex(indexData);
    }

    /**
     * Parse the decrypted index buffer.
     * Layout: mount_point_string | num_files | files[n] | num_dirs | dirs...
     */
    private void parseIndex(byte[] data) throws IOException {
        ByteBuffer buf = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);

        // mount point
        String mountPoint = readString(buf);

        // files
        int numFiles = buf.getInt();
        files = new ArrayList<>(numFiles);
        for (int i = 0; i < numFiles; i++) {
            TencentPakEntry entry = TencentPakEntry.read(buf, pakInfo.version);
            files.add(entry);
        }

        // directories
        long numDirs = buf.getLong();
        index = new LinkedHashMap<>();

        for (long d = 0; d < numDirs; d++) {
            String dirPath = readString(buf);
            long numEntries = buf.getLong();
            Map<String, TencentPakEntry> dirMap = new LinkedHashMap<>();

            for (long f = 0; f < numEntries; f++) {
                String fname = readString(buf);
                int slot = buf.getInt();  // negative: ~slot gives file index
                int fileIdx = ~slot;
                if (fileIdx >= 0 && fileIdx < files.size()) {
                    TencentPakEntry entry = files.get(fileIdx);
                    entry.dirPath  = dirPath;
                    entry.fileName = fname;
                    dirMap.put(fname, entry);
                }
            }
            index.put(dirPath, dirMap);
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // Public accessors
    // ════════════════════════════════════════════════════════════════════

    public TencentPakInfo getPakInfo()     { return pakInfo; }
    public List<TencentPakEntry> getFiles(){ return files; }
    public Map<String, Map<String, TencentPakEntry>> getIndex() { return index; }
    public int getVersion()                { return pakInfo.version; }
    public int getTotalFileCount()         { return files.size(); }
    public File getFilePath()              { return filePath; }

    // ════════════════════════════════════════════════════════════════════
    // Dominant style detection (for inject defaults)
    // ════════════════════════════════════════════════════════════════════

    public Map<String, Object> detectDominantStyle() {
        Map<Integer, Integer> compCounter = new HashMap<>();
        Map<Integer, Integer> encCounter  = new HashMap<>();
        Map<Integer, Integer> blkCounter  = new HashMap<>();
        int encCount = 0, plainCount = 0;

        for (TencentPakEntry e : files) {
            compCounter.merge(e.compressionMethod, 1, Integer::sum);
            if (e.encrypted) {
                encCounter.merge(e.encryptionMethod, 1, Integer::sum);
                encCount++;
            } else {
                plainCount++;
            }
            if (e.compressionBlockSize > 0)
                blkCounter.merge(e.compressionBlockSize, 1, Integer::sum);
        }

        int compMethod = PakCrypto.CM_ZSTD;
        int bestComp = 0;
        for (Map.Entry<Integer, Integer> kv : compCounter.entrySet()) {
            if (kv.getKey() != PakCrypto.CM_NONE && kv.getValue() > bestComp) {
                bestComp    = kv.getValue();
                compMethod  = kv.getKey();
            }
        }

        boolean encrypted = encCount > plainCount;
        int encMethod = 0;
        int bestEnc = 0;
        for (Map.Entry<Integer, Integer> kv : encCounter.entrySet()) {
            if (kv.getValue() > bestEnc) { bestEnc = kv.getValue(); encMethod = kv.getKey(); }
        }

        int blockSize = 0x10000;
        int bestBlk = 0;
        for (Map.Entry<Integer, Integer> kv : blkCounter.entrySet()) {
            if (kv.getValue() > bestBlk) { bestBlk = kv.getValue(); blockSize = kv.getKey(); }
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("comp_method", compMethod);
        result.put("enc_method",  encMethod);
        result.put("encrypted",   encrypted);
        result.put("block_size",  blockSize);
        return result;
    }

    // ════════════════════════════════════════════════════════════════════
    // Extract all files
    // ════════════════════════════════════════════════════════════════════

    /**
     * Extracts all PAK entries to {@code outDir}.
     * Mirrors Python TencentPakFile.extract_all().
     */
    public void extractAll(File outDir, ProgressCallback cb) throws IOException {
        int total = files.size();
        int done  = 0;

        for (Map.Entry<String, Map<String, TencentPakEntry>> dirEntry : index.entrySet()) {
            String dirPath = sanitizePath(dirEntry.getKey());
            File targetDir = dirPath.isEmpty() ? outDir : new File(outDir, dirPath);
            //noinspection ResultOfMethodCallIgnored
            targetDir.mkdirs();

            for (Map.Entry<String, TencentPakEntry> fileEntry : dirEntry.getValue().entrySet()) {
                String safeName = sanitizeFilename(fileEntry.getKey());
                TencentPakEntry entry = fileEntry.getValue();
                File outFile = new File(targetDir, safeName);

                try {
                    byte[] data = extractEntry(entry);
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        fos.write(data);
                    }
                } catch (Exception ex) {
                    if (cb != null) cb.onLog("⚠ Skipped " + safeName + ": " + ex.getMessage());
                }

                done++;
                if (cb != null) cb.onProgress(done, total, safeName);
            }
        }
    }

    /**
     * Extracts and decodes a single entry's raw bytes.
     * Steps: read raw → decrypt blocks → reorder (permutation inverse) → decompress.
     */
    public byte[] extractEntry(TencentPakEntry entry) throws IOException {
        if (entry.uncompressedSize == 0) return new byte[0];

        long[] ks = PakCrypto.zucKeystream();
        String stem = fileStem(entry.fullPath());

        if (entry.compressionMethod == PakCrypto.CM_NONE) {
            // No compression: raw stored data (possibly encrypted)
            byte[] raw = Arrays.copyOfRange(fileContent,
                    (int) entry.offset, (int)(entry.offset + entry.size));
            if (entry.encrypted) {
                raw = PakCrypto.decryptBlock(raw, stem, entry.encryptionMethod);
                // Trim to uncompressed size (padding bytes at end)
                if (raw.length > entry.uncompressedSize)
                    raw = Arrays.copyOf(raw, (int) entry.uncompressedSize);
            }
            return raw;
        }

        // Compressed: collect physical blocks in logical order
        int nBlocks = entry.compressedBlocks.size();
        if (nBlocks == 0) return new byte[0];

        int[] physicalOrder = PakCrypto.generateBlockIndices(nBlocks, entry.encryptionMethod);
        // physicalOrder[logicalIdx] = physicalIdx  →  to read logical order we need the inverse
        // Actually: inverse[physicalIdx] = logicalIdx means physical[inverse] → build logical[]
        byte[][] logicalBlocks = new byte[nBlocks][];

        for (int physIdx = 0; physIdx < nBlocks; physIdx++) {
            long[] blk = entry.compressedBlocks.get(physIdx);
            int start = (int) blk[0];
            int end   = (int) blk[1];
            byte[] physData = Arrays.copyOfRange(fileContent, start, end);

            if (entry.encrypted) {
                physData = PakCrypto.decryptBlock(physData, stem, entry.encryptionMethod);
            }

            // Find which logical slot this physical block belongs to
            int logicalIdx = physIdx;   // default: no permutation
            for (int li = 0; li < nBlocks; li++) {
                if (physicalOrder[li] == physIdx) { logicalIdx = li; break; }
            }
            logicalBlocks[logicalIdx] = physData;
        }

        // Decompress each logical block and concatenate
        ByteArrayOutputStream result = new ByteArrayOutputStream();
        for (byte[] logBlock : logicalBlocks) {
            if (logBlock == null) continue;
            byte[] decompressed = decompress(logBlock, entry.compressionMethod);
            result.write(decompressed);
        }

        return result.toByteArray();
    }

    // ════════════════════════════════════════════════════════════════════
    // Inject / Repack
    // ════════════════════════════════════════════════════════════════════

    /**
     * Injects new files into this PAK and writes the result to {@code outputFile}.
     * Mirrors Python TencentPakFile.inject_files().
     *
     * @param injectPlan list of InjectItem describing what to insert
     * @param outputFile destination .pak file
     * @param cb         optional progress callback
     */
    public void injectFiles(List<InjectItem> injectPlan, File outputFile,
                             boolean addSignatureMarker, ProgressCallback cb)
            throws IOException {
        if (injectPlan == null || injectPlan.isEmpty())
            throw new IllegalArgumentException("injectPlan is empty — nothing to inject");

        long[] ks       = PakCrypto.zucKeystream();
        int    version  = pakInfo.version;
        long   origIndexOffset = pakInfo.indexOffset;

        // ── STEP 1: encode injected files ────────────────────────────
        if (cb != null) cb.onLog("STEP 1/5: Encoding inject files...");

        long currentOffset      = origIndexOffset;
        ByteArrayOutputStream newDataRegion = new ByteArrayOutputStream();
        List<TencentPakEntry> injectedEntries = new ArrayList<>();

        for (int i = 0; i < injectPlan.size(); i++) {
            InjectItem item = injectPlan.get(i);
            if (cb != null) cb.onProgress(i + 1, injectPlan.size(), item.internalPath);

            byte[] plain = item.plainBytes;

            if (plain.length == 0) {
                // Empty entry
                TencentPakEntry e = new TencentPakEntry();
                e.contentHash         = sha1(new byte[0]);
                e.offset              = currentOffset;
                e.uncompressedSize    = 0;
                e.size                = 0;
                e.compressionMethod   = PakCrypto.CM_NONE;
                e.encryptionMethod    = 0;
                e.encrypted           = false;
                e.compressionBlockSize= 0;
                e.dirPath  = dirOfPath(item.internalPath);
                e.fileName = nameOfPath(item.internalPath);
                injectedEntries.add(e);
                continue;
            }

            String stem = fileStemFromInternalPath(item.internalPath);
            byte[] storedData;
            long   newSize;
            List<long[]> newBlocks = new ArrayList<>();

            if (item.compMethod == PakCrypto.CM_NONE) {
                // No compression
                if (item.encrypted) {
                    int aligned = PakCrypto.alignEncryptedContentSize(plain.length, item.encMethod);
                    byte[] padded = Arrays.copyOf(plain, aligned);
                    storedData = PakCrypto.encryptBlock(padded, stem, item.encMethod);
                } else {
                    storedData = plain;
                }
                newSize = storedData.length;
            } else {
                // Chunk + compress + encrypt + permute
                int blockSz = item.blockSize > 0 ? item.blockSize : 0x10000;
                int nChunks = (int) Math.ceil((double) plain.length / blockSz);
                byte[][] chunks = new byte[nChunks][];
                for (int c = 0; c < nChunks; c++) {
                    int from = c * blockSz;
                    int to   = Math.min(from + blockSz, plain.length);
                    chunks[c] = Arrays.copyOfRange(plain, from, to);
                }

                // Compress each chunk
                byte[][] compChunks = new byte[nChunks][];
                for (int c = 0; c < nChunks; c++) {
                    compChunks[c] = compress(chunks[c], item.compMethod, zstdDict);
                }

                // Encrypt each chunk
                if (item.encrypted) {
                    for (int c = 0; c < nChunks; c++) {
                        compChunks[c] = PakCrypto.encryptBlock(compChunks[c], stem, item.encMethod);
                    }
                }

                // Apply block permutation (SM4 files only)
                int[] perm = PakCrypto.generateBlockIndices(nChunks, item.encMethod);
                byte[][] physBlocks = new byte[nChunks][];
                for (int logIdx = 0; logIdx < nChunks; logIdx++) {
                    physBlocks[perm[logIdx]] = compChunks[logIdx];
                }

                // Compute physical block offsets and assemble data
                long blockCursor = currentOffset;
                ByteArrayOutputStream assembled = new ByteArrayOutputStream();
                for (byte[] pb : physBlocks) {
                    long start = blockCursor;
                    long end   = start + pb.length;
                    newBlocks.add(new long[]{start, end});
                    assembled.write(pb);
                    blockCursor += pb.length;
                }
                storedData = assembled.toByteArray();
                newSize    = storedData.length;
            }

            byte[] contentHash = sha1(storedData);
            newDataRegion.write(storedData);

            TencentPakEntry e = new TencentPakEntry();
            e.contentHash         = contentHash;
            e.offset              = currentOffset;
            e.uncompressedSize    = plain.length;
            e.size                = newSize;
            e.compressionMethod   = item.compMethod;
            e.encryptionMethod    = item.encrypted ? item.encMethod : 0;
            e.encrypted           = item.encrypted;
            e.compressionBlockSize= item.blockSize;
            e.compressedBlocks    = newBlocks;
            e.unk1                = 0;
            e.unk2                = new byte[20];
            e.indexNewSep         = 0;
            e.dirPath             = dirOfPath(item.internalPath);
            e.fileName            = nameOfPath(item.internalPath);
            injectedEntries.add(e);

            currentOffset += newSize;
        }
        if (cb != null) cb.onLog("✔ Encoded " + injectedEntries.size() + " file(s)");

        // ── STEP 2: build new entry list (existing + injected) ────────
        if (cb != null) cb.onLog("STEP 2/5: Merging entries...");

        List<TencentPakEntry> allEntries = new ArrayList<>(files);
        allEntries.addAll(injectedEntries);

        // Optional signature marker
        if (addSignatureMarker) {
            boolean hasMarker = false;
            for (TencentPakEntry e : allEntries) {
                if ("NaveenRx100".equals(e.dirPath) && "PATCHED.txt".equals(e.fileName)) {
                    hasMarker = true; break;
                }
            }
            if (!hasMarker) {
                TencentPakEntry marker = new TencentPakEntry();
                marker.contentHash = sha1(new byte[0]);
                marker.offset      = currentOffset;
                marker.uncompressedSize = 0;
                marker.size        = 0;
                marker.compressionMethod = PakCrypto.CM_NONE;
                marker.dirPath  = "NaveenRx100";
                marker.fileName = "PATCHED.txt";
                allEntries.add(marker);
            }
        }

        // ── STEP 3: build new index ───────────────────────────────────
        if (cb != null) cb.onLog("STEP 3/5: Building new index...");
        byte[] newIndexPlain = buildIndex(allEntries, version);

        // ── STEP 4: encrypt index ─────────────────────────────────────
        if (cb != null) cb.onLog("STEP 4/5: Encrypting index...");
        byte[] newIndexEnc = PakCrypto.encryptIndex(
                newIndexPlain, version, pakInfo.indexEncrypted,
                pakInfo.packedKey.length == 256 ? pakInfo.packedKey : null,
                pakInfo.packedIv.length  == 256 ? pakInfo.packedIv  : null);

        // ── STEP 5: write output PAK ──────────────────────────────────
        if (cb != null) cb.onLog("STEP 5/5: Writing output PAK...");

        long newIndexOffset = origIndexOffset + newDataRegion.size();
        long newIndexSize   = newIndexEnc.length;

        byte[] indexHash = sha1(newIndexPlain);

        // Build footer
        byte[] footer = buildFooter(ks, version, newIndexOffset, newIndexSize, indexHash);

        // Write: [original data up to index] + [new data region] + [new encrypted index] + [footer]
        outputFile.getParentFile().mkdirs();
        try (FileOutputStream fos = new FileOutputStream(outputFile)) {
            fos.write(fileContent, 0, (int) origIndexOffset);
            fos.write(newDataRegion.toByteArray());
            fos.write(newIndexEnc);
            fos.write(footer);
        }

        if (cb != null) cb.onLog("✅ Inject complete → " + outputFile.getName());
    }

    // ════════════════════════════════════════════════════════════════════
    // Build a brand-new PAK from a folder
    // ════════════════════════════════════════════════════════════════════

    /**
     * Build a new Tencent PAK (version 11) from all files in {@code sourceDir}.
     * All files use ZSTD compression, no encryption, block size = 64 KB.
     */
    public static void buildNewPak(File sourceDir, File outputFile,
                                    int compMethod, int encMethod, boolean encrypted,
                                    int blockSize, ProgressCallback cb)
            throws IOException {
        List<File> allFiles = new ArrayList<>();
        collectFiles(sourceDir, allFiles);

        long[] ks = PakCrypto.zucKeystream();
        int version = 11;

        long currentOffset = 0;
        ByteArrayOutputStream dataRegion = new ByteArrayOutputStream();
        List<TencentPakEntry> entries    = new ArrayList<>();

        for (int i = 0; i < allFiles.size(); i++) {
            File f = allFiles.get(i);
            String relPath = sourceDir.toURI().relativize(f.toURI()).getPath()
                    .replace('\\', '/');
            if (cb != null) cb.onProgress(i + 1, allFiles.size(), relPath);

            byte[] plain = readAllBytes(f);
            String stem  = fileStem(relPath);

            byte[] storedData;
            List<long[]> blocks = new ArrayList<>();
            long fileSize;

            if (plain.length == 0 || compMethod == PakCrypto.CM_NONE) {
                storedData = plain;
                fileSize   = storedData.length;
            } else {
                int bsz = blockSize > 0 ? blockSize : 0x10000;
                int nChunks = Math.max(1, (int) Math.ceil((double) plain.length / bsz));
                byte[][] compChunks = new byte[nChunks][];
                for (int c = 0; c < nChunks; c++) {
                    int from = c * bsz;
                    int to   = Math.min(from + bsz, plain.length);
                    compChunks[c] = compress(Arrays.copyOfRange(plain, from, to), compMethod, null);
                    if (encrypted)
                        compChunks[c] = PakCrypto.encryptBlock(compChunks[c], stem, encMethod);
                }
                int[] perm = PakCrypto.generateBlockIndices(nChunks, encMethod);
                byte[][] physBlocks = new byte[nChunks][];
                for (int li = 0; li < nChunks; li++) physBlocks[perm[li]] = compChunks[li];

                long cursor = currentOffset;
                ByteArrayOutputStream assembled = new ByteArrayOutputStream();
                for (byte[] pb : physBlocks) {
                    blocks.add(new long[]{cursor, cursor + pb.length});
                    assembled.write(pb);
                    cursor += pb.length;
                }
                storedData = assembled.toByteArray();
                fileSize   = storedData.length;
            }

            dataRegion.write(storedData);

            TencentPakEntry e = new TencentPakEntry();
            e.contentHash = sha1(storedData);
            e.offset      = currentOffset;
            e.uncompressedSize = plain.length;
            e.size        = fileSize;
            e.compressionMethod  = compMethod;
            e.encryptionMethod   = encrypted ? encMethod : 0;
            e.encrypted          = encrypted;
            e.compressionBlockSize = blockSize;
            e.compressedBlocks   = blocks;
            e.dirPath  = dirOfPath(relPath);
            e.fileName = nameOfPath(relPath);
            entries.add(e);

            currentOffset += fileSize;
        }

        byte[] indexPlain = buildIndex(entries, version);
        // New PAK: no index encryption
        byte[] indexBytes = indexPlain;
        long indexOffset  = currentOffset;
        long indexSize    = indexBytes.length;
        byte[] indexHash  = sha1(indexPlain);

        byte[] footer = buildFooter(ks, version, indexOffset, indexSize, indexHash);

        outputFile.getParentFile().mkdirs();
        try (FileOutputStream fos = new FileOutputStream(outputFile)) {
            fos.write(dataRegion.toByteArray());
            fos.write(indexBytes);
            fos.write(footer);
        }

        if (cb != null) cb.onLog("✅ New PAK built → " + outputFile.getName()
                + " (" + entries.size() + " files)");
    }

    // ════════════════════════════════════════════════════════════════════
    // Index builder
    // ════════════════════════════════════════════════════════════════════

    /**
     * Serializes the entry list + directory tree into raw index bytes.
     * Layout: mountPoint | numFiles | entries[] | numDirs | dirs[]
     * Terminated with: \x1d\x00\x00\x00\x2e\x2e
     */
    private static byte[] buildIndex(List<TencentPakEntry> allEntries, int version)
            throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();

        // mount point (empty string → length 0)
        writeString(buf, "");

        // num files
        writeLE32(buf, allEntries.size());

        // entry data
        for (TencentPakEntry e : allEntries) {
            buf.write(e.toBytes(version));
        }

        // Collect directory tree
        // dir → [ (fileName, fileIndex) ]
        Map<String, List<Object[]>> dirMap = new LinkedHashMap<>();
        for (int i = 0; i < allEntries.size(); i++) {
            TencentPakEntry e = allEntries.get(i);
            dirMap.computeIfAbsent(e.dirPath, k -> new ArrayList<>())
                  .add(new Object[]{e.fileName, i});
        }

        // num dirs
        writeLE64(buf, dirMap.size());

        for (Map.Entry<String, List<Object[]>> de : dirMap.entrySet()) {
            String dir = de.getKey();
            if (dir == null || dir.isEmpty() || dir.equals(".")) {
                writeLE32(buf, 0);
            } else {
                if (!dir.endsWith("/")) dir = dir + "/";
                byte[] dirBytes = (dir + "\0").getBytes("UTF-8");
                writeLE32(buf, dirBytes.length);
                buf.write(dirBytes);
            }
            List<Object[]> filesInDir = de.getValue();
            writeLE64(buf, filesInDir.size());
            for (Object[] fe : filesInDir) {
                String fname = (String) fe[0];
                int fileIdx  = (int)    fe[1];
                byte[] nameBytes = (fname + "\0").getBytes("UTF-8");
                writeLE32(buf, nameBytes.length);
                buf.write(nameBytes);
                // Slot = ~fileIdx (negative index)
                writeLE32(buf, ~fileIdx);
            }
        }

        // Terminator bytes (from Python: b'\x1d\x00\x00\x00\x2e\x2e')
        buf.write(new byte[]{0x1d, 0x00, 0x00, 0x00, 0x2e, 0x2e});

        return buf.toByteArray();
    }

    // ════════════════════════════════════════════════════════════════════
    // Footer builder
    // ════════════════════════════════════════════════════════════════════

    /**
     * Builds the encrypted PAK footer for a given version.
     * Mirrors the Python inject_files() footer writing block.
     */
    private byte[] buildFooter(long[] ks, int version,
                                long newIndexOffset, long newIndexSize,
                                byte[] indexHash) throws IOException {
        ByteArrayOutputStream foot = new ByteArrayOutputStream();

        // ── Version ≥ 7: unk1 (encrypted) ────────────────────────────
        if (version >= 7) {
            byte[] unk1plain = (pakInfo.unk1 != null && pakInfo.unk1.length == 32)
                    ? pakInfo.unk1 : new byte[32];
            byte[] ksBytes = new byte[32];
            ByteBuffer ksb = ByteBuffer.wrap(ksBytes).order(ByteOrder.LITTLE_ENDIAN);
            for (int i = 7; i < 15; i++) ksb.putInt((int)(ks[i] & 0xFFFFFFFFL));
            byte[] encUnk1 = new byte[32];
            for (int i = 0; i < 32; i++) encUnk1[i] = (byte)(unk1plain[i] ^ ksBytes[i]);
            foot.write(encUnk1);
        }
        // ── Version ≥ 8: packed key / iv / index_hash ─────────────────
        if (version >= 8) {
            foot.write(pakInfo.packedKey.length == 256 ? pakInfo.packedKey : new byte[256]);
            foot.write(pakInfo.packedIv.length  == 256 ? pakInfo.packedIv  : new byte[256]);
            foot.write(pakInfo.packedIndexHash.length == 256 ? pakInfo.packedIndexHash : new byte[256]);
        }
        // ── Version ≥ 9: stem_hash, unk2 ─────────────────────────────
        if (version >= 9) {
            writeLE32(foot, (int)((pakInfo.stemHash ^ ks[8]) & 0xFFFFFFFFL));
            writeLE32(foot, (int)((pakInfo.unk2     ^ ks[9]) & 0xFFFFFFFFL));
        }
        // ── Version ≥ 12: content_org_hash ───────────────────────────
        if (version >= 12) {
            foot.write(pakInfo.contentOrgHash.length == 20 ? pakInfo.contentOrgHash : new byte[20]);
        }

        // ── Base 45-byte block ────────────────────────────────────────
        // index_encrypted flag
        int encFlag = PakCrypto.encryptIndexEncryptedFlag(pakInfo.indexEncrypted, ks);
        foot.write(encFlag & 0xFF);

        // magic (XOR ks[2])
        long encMagic = PakCrypto.encryptMagic(pakInfo.magic, ks);
        writeLE32(foot, (int)(encMagic & 0xFFFFFFFFL));

        // version (plain)
        writeLE32(foot, version);

        // index_hash (XOR ks[4..8])
        if (version >= 6) {
            foot.write(PakCrypto.encryptIndexHash(indexHash, ks));
        } else {
            foot.write(new byte[20]);
        }

        // index_size (XOR)
        writeLE64(foot, PakCrypto.encryptIndexSize(newIndexSize, ks));

        // index_offset (XOR)
        writeLE64(foot, PakCrypto.encryptIndexOffset(newIndexOffset, ks));

        return foot.toByteArray();
    }

    // ════════════════════════════════════════════════════════════════════
    // Compression helpers
    // ════════════════════════════════════════════════════════════════════

    private static byte[] decompress(byte[] data, int method) throws IOException {
        switch (method) {
            case PakCrypto.CM_ZLIB: return zlibDecompress(data);
            case PakCrypto.CM_ZSTD:
            case PakCrypto.CM_ZSTD_DICT:
                return zstdDecompress(data);
            default: return data;
        }
    }

    private static byte[] compress(byte[] data, int method, byte[] dictData) throws IOException {
        switch (method) {
            case PakCrypto.CM_ZLIB: return zlibCompress(data);
            case PakCrypto.CM_ZSTD:
            case PakCrypto.CM_ZSTD_DICT:
                return zstdCompress(data, dictData, method == PakCrypto.CM_ZSTD_DICT);
            default: return data;
        }
    }

    private static byte[] zlibDecompress(byte[] data) throws IOException {
        Inflater inflater = new Inflater();
        inflater.setInput(data);
        ByteArrayOutputStream out = new ByteArrayOutputStream(data.length * 4);
        byte[] buf = new byte[8192];
        try {
            while (!inflater.finished()) {
                int count = inflater.inflate(buf);
                if (count == 0) break;
                out.write(buf, 0, count);
            }
        } catch (DataFormatException e) {
            throw new IOException("Zlib decompression failed", e);
        } finally {
            inflater.end();
        }
        return out.toByteArray();
    }

    private static byte[] zlibCompress(byte[] data) {
        Deflater deflater = new Deflater(Deflater.BEST_COMPRESSION);
        deflater.setInput(data);
        deflater.finish();
        ByteArrayOutputStream out = new ByteArrayOutputStream(data.length);
        byte[] buf = new byte[8192];
        while (!deflater.finished()) {
            int count = deflater.deflate(buf);
            out.write(buf, 0, count);
        }
        deflater.end();
        return out.toByteArray();
    }

    private static byte[] zstdDecompress(byte[] data) throws IOException {
        try (ZstdDecompressCtx ctx = new ZstdDecompressCtx()) {
            return ctx.decompress(data, data.length * 10);
        } catch (Exception e) {
            throw new IOException("Zstd decompression failed", e);
        }
    }

    private static byte[] zstdCompress(byte[] data, byte[] dictData, boolean useDict)
            throws IOException {
        try (ZstdCompressCtx ctx = new ZstdCompressCtx()) {
            ctx.setLevel(19);
            if (useDict && dictData != null) {
                ctx.loadDict(dictData);
            }
            return ctx.compress(data);
        } catch (Exception e) {
            throw new IOException("Zstd compression failed", e);
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // Utility helpers
    // ════════════════════════════════════════════════════════════════════

    private static byte[] readAllBytes(File f) throws IOException {
        try (FileInputStream fis = new FileInputStream(f)) {
            byte[] data = new byte[(int) f.length()];
            int read = 0;
            while (read < data.length) {
                int r = fis.read(data, read, data.length - read);
                if (r < 0) break;
                read += r;
            }
            return data;
        }
    }

    private static void collectFiles(File dir, List<File> out) {
        File[] children = dir.listFiles();
        if (children == null) return;
        Arrays.sort(children);
        for (File f : children) {
            if (f.isDirectory()) collectFiles(f, out);
            else out.add(f);
        }
    }

    private static byte[] sha1(byte[] data) {
        try {
            return MessageDigest.getInstance("SHA-1").digest(data);
        } catch (Exception e) { return new byte[20]; }
    }

    /** Read a Pascal-style length-prefixed string from a LE ByteBuffer. */
    private static String readString(ByteBuffer buf) {
        int len = buf.getInt();
        if (len == 0) return "";
        byte[] bytes = new byte[len];
        buf.get(bytes);
        // Strip trailing null terminator
        int end = bytes.length;
        while (end > 0 && bytes[end - 1] == 0) end--;
        try { return new String(bytes, 0, end, "UTF-8"); }
        catch (Exception e) { return new String(bytes, 0, end); }
    }

    private static void writeString(ByteArrayOutputStream out, String s) throws IOException {
        if (s == null || s.isEmpty()) { writeLE32(out, 0); return; }
        byte[] bytes = (s + "\0").getBytes("UTF-8");
        writeLE32(out, bytes.length);
        out.write(bytes);
    }

    private static void writeLE32(ByteArrayOutputStream out, long v) {
        out.write((int)(v)       & 0xFF);
        out.write((int)(v >>  8) & 0xFF);
        out.write((int)(v >> 16) & 0xFF);
        out.write((int)(v >> 24) & 0xFF);
    }

    private static void writeLE64(ByteArrayOutputStream out, long v) {
        writeLE32(out, v & 0xFFFFFFFFL);
        writeLE32(out, (v >>> 32) & 0xFFFFFFFFL);
    }

    private static String sanitizePath(String s) {
        if (s == null || s.isEmpty() || s.equals(".")) return "";
        return s.replaceAll("[\\x00-\\x1f<>:\"|?*]", "")
                .replace('\\', '/').replaceAll("/$", "");
    }

    private static String sanitizeFilename(String s) {
        if (s == null || s.isEmpty()) return "_";
        String out = s.replaceAll("[\\x00-\\x1f<>:\"/\\\\|?*\u007f]", "")
                       .replaceAll("[. ]+$", "");
        if (out.isEmpty() || out.equals(".") || out.equals("..")) out = "_";
        return out;
    }

    private static String fileStem(String path) {
        int slash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        String name = slash >= 0 ? path.substring(slash + 1) : path;
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot).toLowerCase() : name.toLowerCase();
    }

    private static String fileStemFromInternalPath(String internalPath) {
        return fileStem(internalPath);
    }

    private static String dirOfPath(String path) {
        path = path.replace('\\', '/').replaceAll("^/", "");
        int slash = path.lastIndexOf('/');
        return slash >= 0 ? path.substring(0, slash) : "";
    }

    private static String nameOfPath(String path) {
        path = path.replace('\\', '/');
        int slash = path.lastIndexOf('/');
        return slash >= 0 ? path.substring(slash + 1) : path;
    }

    // ════════════════════════════════════════════════════════════════════
    // InjectItem data class
    // ════════════════════════════════════════════════════════════════════

    /**
     * Describes a single file to be injected into a PAK.
     * Mirrors the inject_plan list entries in Python.
     */
    public static final class InjectItem {
        public final byte[] plainBytes;     // raw file content
        public final String internalPath;   // e.g. "Engine/Content/foo.lua"
        public final int    compMethod;     // CM_NONE / CM_ZLIB / CM_ZSTD / CM_ZSTD_DICT
        public final int    encMethod;      // EM_SIMPLE1 / EM_SM4_2 / etc.
        public final boolean encrypted;
        public final int    blockSize;      // compression block size (e.g. 65536)

        public InjectItem(byte[] plainBytes, String internalPath,
                          int compMethod, int encMethod, boolean encrypted, int blockSize) {
            this.plainBytes    = plainBytes;
            this.internalPath  = internalPath.replace('\\', '/').replaceAll("^/", "");
            this.compMethod    = compMethod;
            this.encMethod     = encMethod;
            this.encrypted     = encrypted;
            this.blockSize     = blockSize;
        }

        /** Convenience: read file content from disk. */
        public static InjectItem fromFile(File f, String internalPath,
                                           int compMethod, int encMethod,
                                           boolean encrypted, int blockSize) throws IOException {
            byte[] data = readAllBytes(f);
            return new InjectItem(data, internalPath, compMethod, encMethod, encrypted, blockSize);
        }

        private static byte[] readAllBytes(File f) throws IOException {
            try (FileInputStream fis = new FileInputStream(f)) {
                byte[] data = new byte[(int) f.length()];
                fis.read(data);
                return data;
            }
        }
    }
}
