package com.naveenrx100.paktool.core.lua;

import android.content.Context;
import dalvik.system.DexClassLoader;
import android.util.Log;

import com.naveenrx100.paktool.NaveenApplication;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

/**
 * LuaTools — Decompilation and Recompilation pipeline.
 *
 * CREDIT: @NaveenRx100
 *
 * Decompile flow  (mirrors Python action_unpack):
 *  1. Read .luac / .slua from LUA_ORIGINAL
 *  2. LuaConverter.bgmiToStd() → std .luac in temp dir
 *  3. java -jar unluac_patched.jar std.luac → .lua source
 *  4. Save to LUA_EDIT/
 *
 * Recompile flow  (mirrors Python action_repack_unpack):
 *  1. Read .lua from LUA_EDIT
 *  2. luac5.3 -s -o temp_std.luac foo.lua
 *  3. LuaConverter.stdToBgmi(temp_std, original_bgmi) → bgmi .luac
 *  4. Pad to original file size if needed
 *  5. Save to COMPILED/
 *
 * The unluac_patched.jar is bundled in assets/unluac_patched.jar.
 * The luac5.3 native binary is extracted from jniLibs at runtime.
 */
public class LuaTools {

    private static final String TAG = "LuaTools";

    /** Interface for reporting progress and log lines. */
    public interface Callback {
        void onProgress(int current, int total, String filename);
        void onLog(String line);
        void onDone(int success, int failed);
    }

    // ── Paths set up by NaveenApplication ─────────────────────────────
    private static File getLuaOriginalDir() { return NaveenApplication.REAL_DIR; }
    private static File getLuaEditDir()     { return NaveenApplication.UNPACK_DIR; }
    private static File getCompiledDir()    { return NaveenApplication.EDIT_DIR; }

    // ── Jar / binary paths ────────────────────────────────────────────

    private static File getUnluacJar(Context ctx) {
        // Android cannot execute "java -jar". Use a DEX file supplied in assets.
        File dex = new File(ctx.getCodeCacheDir(), "unluac_patched.dex");
        if (!dex.exists()) {
            try {
                extractAsset(ctx, "unluac_patched.dex", dex);
            } catch (IOException e) {
                Log.e(TAG, "Cannot extract assets/unluac_patched.dex. Convert the patched JAR to DEX first.", e);
            }
        }
        return dex;
    }

    private static File getLuacBinary(Context ctx) {
        // This is a standalone Android ARM64 executable, not a JNI shared library.
        // Extract it from assets and execute it directly with ProcessBuilder.
        File bin = new File(ctx.getCacheDir(), "luac5.3");
        try {
            if (!bin.exists() || bin.length() == 0) {
                extractAsset(ctx, "luac5.3", bin);
            }
            // Validate ELF magic and ARM64 ELF class before execution.
            try (FileInputStream in = new FileInputStream(bin)) {
                byte[] header = new byte[20];
                if (in.read(header) < header.length || header[0] != 0x7f ||
                        header[1] != 'E' || header[2] != 'L' || header[3] != 'F' ||
                        header[4] != 2 || header[5] != 1 ||
                        header[18] != (byte) 0xb7 || header[19] != 0) {
                    throw new IOException("luac5.3 asset is not an Android ARM64 ELF executable");
                }
            }
            if (!bin.setExecutable(true, true) && !bin.canExecute()) {
                throw new IOException("Cannot mark luac5.3 executable");
            }
        } catch (IOException e) {
            Log.e(TAG, "Cannot prepare luac5.3", e);
        }
        return bin;
    }

    // ════════════════════════════════════════════════════════════════════
    // Decompile (BGMI .luac → .lua source)
    // ════════════════════════════════════════════════════════════════════

    /**
     * Decompiles a single BGMI .luac file to .lua source.
     *
     * @param ctx      Android context
     * @param input    path to the BGMI .luac / .slua file
     * @param outputDir directory to write the .lua file
     * @return path to the decompiled .lua, or null on failure
     */
    public static String decompileFile(Context ctx, File input, File outputDir) {
        String base = baseName(input.getName());
        File stdLuac = new File(ctx.getCacheDir(), base + ".std.luac");
        File outLua  = new File(outputDir, base + ".lua");

        try {
            // Step 1: read input
            byte[] data = readAllBytes(input);
            if (data.length < 4 || data[0] != 0x1b) {
                // Not a bytecode file — copy as-is
                copyFile(input, outLua);
                return outLua.getAbsolutePath();
            }

            // Step 2: BGMI → std
            byte[] stdData;
            try {
                stdData = LuaConverter.bgmiToStd(data);
            } catch (LuaConverter.LuaConvertException ex) {
                Log.w(TAG, "bgmiToStd failed, using raw: " + ex.getMessage());
                stdData = data;
            }
            writeAllBytes(stdLuac, stdData);

            // Step 3: unluac
            File jar = getUnluacJar(ctx);
            if (!jar.exists()) {
                Log.w(TAG, "unluac_patched.dex missing — saving raw bytecode");
                copyFile(stdLuac, new File(outputDir, base + ".luac"));
                return null;
            }

            byte[] luaSource = runUnluacDex(ctx, jar, stdLuac);
            if (luaSource.length > 0) {
                writeAllBytes(outLua, luaSource);
                return outLua.getAbsolutePath();
            } else {
                Log.w(TAG, "unluac produced no source for " + input.getName());
                // Save std bytecode as fallback
                copyFile(stdLuac, new File(outputDir, base + ".luac"));
                return null;
            }
        } catch (Exception ex) {
            Log.e(TAG, "decompileFile error: " + ex.getMessage());
            return null;
        } finally {
            stdLuac.delete();
        }
    }

    /**
     * Invoke unluac.Main.main(String[]) from a DEX file. The DEX must contain
     * the patched unluac classes and be built for Android-compatible bytecode.
     * unluac writes its decompiled source to System.out.
     */
    private static byte[] runUnluacDex(Context ctx, File dexFile, File bytecode) throws Exception {
        if (!dexFile.isFile() || dexFile.length() == 0) {
            throw new IOException("Missing assets/unluac_patched.dex");
        }
        File optimized = new File(ctx.getCodeCacheDir(), "unluac_opt");
        if (!optimized.exists() && !optimized.mkdirs()) {
            throw new IOException("Cannot create DEX optimization directory");
        }
        DexClassLoader loader = new DexClassLoader(dexFile.getAbsolutePath(),
                optimized.getAbsolutePath(), null, ctx.getClassLoader());
        Class<?> mainClass = loader.loadClass("unluac.Main");
        Method main = mainClass.getMethod("main", String[].class);
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        PrintStream capture = new PrintStream(output, true, "UTF-8");
        PrintStream previous = System.out;
        try {
            System.setOut(capture);
            main.invoke(null, (Object) new String[]{bytecode.getAbsolutePath()});
        } finally {
            System.setOut(previous);
            capture.close();
            try { loader.close(); } catch (Exception ignored) {}
        }
        return output.toByteArray();
    }

    // ════════════════════════════════════════════════════════════════════
    // Recompile (.lua source → BGMI .luac)
    // ════════════════════════════════════════════════════════════════════

    /**
     * Compiles a .lua source file back to BGMI-encoded bytecode.
     *
     * @param ctx       Android context
     * @param luaSource .lua file from LUA_EDIT
     * @param originalBgmi the original .luac from LUA_ORIGINAL (for header)
     * @param outputDir directory to write the final BGMI .luac
     * @return true on success
     */
    public static boolean recompileFile(Context ctx, File luaSource,
                                         File originalBgmi, File outputDir) {
        String base   = baseName(luaSource.getName());
        File stdLuac  = new File(ctx.getCacheDir(), base + "_temp_std.luac");
        File outFile  = new File(outputDir, base + ".lua"); // Lua output keeps .lua ext

        try {
            // Step 1: compile .lua → std .luac using luac5.3
            File luac = getLuacBinary(ctx);
            if (!luac.exists()) {
                Log.e(TAG, "luac5.3 binary not found");
                return false;
            }

            ProcessBuilder pb = new ProcessBuilder(
                    luac.getAbsolutePath(), "-s", "-o",
                    stdLuac.getAbsolutePath(),
                    luaSource.getAbsolutePath());
            pb.redirectErrorStream(true);
            Process proc = pb.start();
            boolean ok = proc.waitFor(30, TimeUnit.SECONDS);
            int rc = ok ? proc.exitValue() : -1;

            if (rc != 0 || !stdLuac.exists()) {
                byte[] errOut = drainStream(proc.getInputStream());
                Log.e(TAG, "luac error: " + new String(errOut));
                return false;
            }

            // Step 2: std → BGMI
            byte[] stdData  = readAllBytes(stdLuac);
            byte[] origData = (originalBgmi != null && originalBgmi.exists())
                    ? readAllBytes(originalBgmi) : null;

            byte[] bgmiData = LuaConverter.stdToBgmi(stdData, origData);

            // Step 3: optionally pad to original size
            if (origData != null && bgmiData.length < origData.length) {
                bgmiData = Arrays.copyOf(bgmiData, origData.length);
            }

            writeAllBytes(outFile, bgmiData);
            return true;
        } catch (Exception ex) {
            Log.e(TAG, "recompileFile error: " + ex.getMessage());
            return false;
        } finally {
            stdLuac.delete();
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // Batch operations
    // ════════════════════════════════════════════════════════════════════

    public static void decompileAll(Context ctx, Callback cb) {
        File srcDir = getLuaOriginalDir();
        File outDir = getLuaEditDir();
        outDir.mkdirs();

        File[] files = srcDir.listFiles(
                f -> f.isFile() && (f.getName().endsWith(".luac") ||
                     f.getName().endsWith(".lua") || f.getName().endsWith(".slua")));
        if (files == null || files.length == 0) {
            if (cb != null) cb.onLog("LUA_ORIGINAL folder is empty");
            if (cb != null) cb.onDone(0, 0);
            return;
        }

        int success = 0, failed = 0;
        for (int i = 0; i < files.length; i++) {
            if (cb != null) cb.onProgress(i + 1, files.length, files[i].getName());
            String result = decompileFile(ctx, files[i], outDir);
            if (result != null) {
                success++;
                if (cb != null) cb.onLog("✔ " + new File(result).getName());
            } else {
                failed++;
                if (cb != null) cb.onLog("✗ " + files[i].getName());
            }
        }
        if (cb != null) cb.onDone(success, failed);
    }

    public static void recompileAll(Context ctx, Callback cb) {
        File srcDir  = getLuaEditDir();
        File outDir  = getCompiledDir();
        File origDir = getLuaOriginalDir();
        outDir.mkdirs();

        File[] files = srcDir.listFiles(f -> f.isFile() && f.getName().endsWith(".lua"));
        if (files == null || files.length == 0) {
            if (cb != null) cb.onLog("LUA_EDIT folder is empty");
            if (cb != null) cb.onDone(0, 0);
            return;
        }

        int success = 0, failed = 0;
        for (int i = 0; i < files.length; i++) {
            String base = baseName(files[i].getName());
            if (cb != null) cb.onProgress(i + 1, files.length, files[i].getName());

            // Find original BGMI file
            File orig = findOriginal(origDir, base);
            boolean ok = recompileFile(ctx, files[i], orig, outDir);
            if (ok) {
                success++;
                if (cb != null) cb.onLog("✔ Compiled: " + base + ".lua");
            } else {
                failed++;
                if (cb != null) cb.onLog("✗ Failed: " + base);
            }
        }
        if (cb != null) cb.onDone(success, failed);
    }

    private static File findOriginal(File dir, String base) {
        for (String ext : new String[]{".luac", ".slua", ".lua"}) {
            File f = new File(dir, base + ext);
            if (f.exists()) return f;
        }
        return null;
    }

    // ════════════════════════════════════════════════════════════════════
    // Utility
    // ════════════════════════════════════════════════════════════════════

    private static void extractAsset(Context ctx, String assetName, File dest) throws IOException {
        try (InputStream in  = ctx.getAssets().open(assetName);
             OutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    static byte[] readAllBytes(File f) throws IOException {
        try (FileInputStream fis = new FileInputStream(f)) {
            byte[] data = new byte[(int) f.length()];
            int read = 0;
            while (read < data.length) {
                int r = fis.read(data, read, data.length - read);
                if (r < 0) break;
                read += r;
            }
            return data;
        }
    }

    private static void writeAllBytes(File f, byte[] data) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write(data);
        }
    }

    private static void copyFile(File src, File dst) throws IOException {
        try (FileInputStream in = new FileInputStream(src);
             FileOutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    private static byte[] drainStream(InputStream is) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096]; int n;
        while ((n = is.read(buf)) > 0) baos.write(buf, 0, n);
        return baos.toByteArray();
    }

    private static String baseName(String name) {
        // Strip one or two extensions: "foo.lua" → "foo", "foo.lua.luac" → "foo.lua"
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private static class ByteArrayOutputStream extends java.io.ByteArrayOutputStream {}
}
