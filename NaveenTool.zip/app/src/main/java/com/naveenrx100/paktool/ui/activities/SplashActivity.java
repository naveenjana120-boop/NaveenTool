package com.naveenrx100.paktool.ui.activities;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.naveenrx100.paktool.NaveenApplication;
import com.naveenrx100.paktool.R;

/**
 * SplashActivity — entry point with animated logo + storage permission request.
 *
 * CREDIT: @NaveenRx100
 */
public class SplashActivity extends AppCompatActivity {

    private static final int PERM_REQUEST_CODE = 100;
    private static final long SPLASH_DURATION  = 2500;

    private ActivityResultLauncher<Intent> manageStorageLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Register manage-storage permission launcher (Android 11+)
        manageStorageLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> proceedAfterPermission());

        // Start animations
        animateSplash();

        // Check / request permissions then continue
        new Handler(Looper.getMainLooper()).postDelayed(
                this::checkPermissions, SPLASH_DURATION);
    }

    // ── Animations ────────────────────────────────────────────────────

    private void animateSplash() {
        View logo      = findViewById(R.id.splash_logo);
        View title     = findViewById(R.id.splash_title);
        View subtitle  = findViewById(R.id.splash_subtitle);
        View tagline   = findViewById(R.id.splash_tagline);
        ProgressBar pb = findViewById(R.id.splash_progress);

        // Logo: scale from 0 + fade in
        logo.setScaleX(0f); logo.setScaleY(0f); logo.setAlpha(0f);
        ObjectAnimator scaleX  = ObjectAnimator.ofFloat(logo, "scaleX", 0f, 1.1f, 1f);
        ObjectAnimator scaleY  = ObjectAnimator.ofFloat(logo, "scaleY", 0f, 1.1f, 1f);
        ObjectAnimator fadeIn  = ObjectAnimator.ofFloat(logo, "alpha",  0f, 1f);
        scaleX.setDuration(700); scaleX.setInterpolator(new OvershootInterpolator(1.5f));
        scaleY.setDuration(700); scaleY.setInterpolator(new OvershootInterpolator(1.5f));
        fadeIn.setDuration(500);

        // Title slide in from bottom
        title.setTranslationY(80f); title.setAlpha(0f);
        ObjectAnimator titleY  = ObjectAnimator.ofFloat(title, "translationY", 80f, 0f);
        ObjectAnimator titleA  = ObjectAnimator.ofFloat(title, "alpha", 0f, 1f);
        titleY.setDuration(600); titleY.setInterpolator(new AccelerateDecelerateInterpolator());
        titleA.setDuration(600);

        subtitle.setAlpha(0f);
        ObjectAnimator subA = ObjectAnimator.ofFloat(subtitle, "alpha", 0f, 1f);
        subA.setDuration(600); subA.setStartDelay(200);

        tagline.setAlpha(0f);
        ObjectAnimator tagA = ObjectAnimator.ofFloat(tagline, "alpha", 0f, 1f);
        tagA.setDuration(600); tagA.setStartDelay(400);

        pb.setAlpha(0f);
        ObjectAnimator pbA = ObjectAnimator.ofFloat(pb, "alpha", 0f, 1f);
        pbA.setDuration(400); pbA.setStartDelay(600);

        AnimatorSet set = new AnimatorSet();
        set.play(scaleX).with(scaleY).with(fadeIn);
        set.play(titleY).with(titleA).after(300);
        set.play(subA).after(300);
        set.play(tagA).after(300);
        set.play(pbA).after(300);
        set.start();
    }

    // ── Permissions ───────────────────────────────────────────────────

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                proceedAfterPermission();
            } else {
                showManageStorageDialog();
            }
        } else {
            String[] perms = {
                android.Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            };
            boolean allGranted = true;
            for (String p : perms) {
                if (ContextCompat.checkSelfPermission(this, p)
                        != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false; break;
                }
            }
            if (allGranted) {
                proceedAfterPermission();
            } else {
                ActivityCompat.requestPermissions(this, perms, PERM_REQUEST_CODE);
            }
        }
    }

    private void showManageStorageDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Storage Permission Required")
            .setMessage(
                "NaveenRx100 PAK Tool needs \"Manage All Files\" permission to\n" +
                "read/write PAK files from /storage/emulated/0/NaveenRx100/.\n\n" +
                "Tap ALLOW and enable it in Settings.")
            .setPositiveButton("ALLOW", (d, w) -> {
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                manageStorageLauncher.launch(intent);
            })
            .setNegativeButton("SKIP", (d, w) -> proceedAfterPermission())
            .setCancelable(false)
            .show();
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(rc, perms, grants);
        proceedAfterPermission();
    }

    private void proceedAfterPermission() {
        // Update progress text
        TextView status = findViewById(R.id.splash_status);
        if (status != null) status.setText("Setting up workspace…");

        // Setup directories (already done in Application, but force re-check here)
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, 500);
    }
}
