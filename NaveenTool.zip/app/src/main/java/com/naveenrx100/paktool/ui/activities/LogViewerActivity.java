package com.naveenrx100.paktool.ui.activities;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.naveenrx100.paktool.R;

/** Generic log / text viewer activity. CREDIT: @NaveenRx100 */
public class LogViewerActivity extends AppCompatActivity {
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_LOG   = "log";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_viewer);

        String title = getIntent().getStringExtra(EXTRA_TITLE);
        String log   = getIntent().getStringExtra(EXTRA_LOG);

        if (getSupportActionBar() != null && title != null)
            getSupportActionBar().setTitle(title);

        TextView tvLog = findViewById(R.id.tv_log_content);
        if (tvLog != null) tvLog.setText(log != null ? log : "(empty)");

        findViewById(R.id.btn_copy).setOnClickListener(v -> {
            android.content.ClipboardManager cm = (android.content.ClipboardManager)
                    getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("log", tvLog.getText()));
            Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show();
        });
    }
}
