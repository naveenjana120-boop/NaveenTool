package com.naveenrx100.paktool;

import android.app.Application;
import android.content.Context;
import androidx.multidex.MultiDex;
import java.io.File;

/**
 * NaveenRx100 PAK Tool — Application class
 * CREDIT: @NaveenRx100
 *
 * Sets up app-wide singletons: directory structure, BouncyCastle provider.
 */
public class NaveenApplication extends Application {

    // ── Developer constants ────────────────────────────────────────────
    public static final String CREDIT      = "@NaveenRx100";
    public static final String DEVELOPER   = "NaveenRx100";
    public static final String TOOL_NAME   = "NaveenRx100 UNLIMITED LUA TOOL";
    public static final String TELEGRAM    = "https://t.me/+POQQ4JunAG9hMWM1";
    public static final String APP_VERSION = "1.0.0";

    // ── App-root working directories (mirrors Python paths) ────────────
    public static File APP_ROOT;
    public static File SOURCE_DIR;
    public static File REAL_DIR;          // LUA_ORIGINAL
    public static File EDIT_DIR;          // COMPILED
    public static File UNPACK_DIR;        // LUA_EDIT
    public static File PAK_DIR;           // PAK_ORIGINAL  / PAK/
    public static File PAK_UNPACK_DIR;    // PAK_UNPACK    / UNPACK/
    public static File RESULT_DIR;        // PAK_RESULT
    public static File BACKUP_DIR;        // BACKUP
    public static File PAK_TOOL_DIR;      // PAK TOOL
    public static File PAK_TOOL_PAK;      // PAK TOOL/PAK
    public static File PAK_TOOL_UNPACK;   // PAK TOOL/UNPACK
    public static File PAK_TOOL_RESULT;   // PAK TOOL/RESULT

    private static NaveenApplication sInstance;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;

        // ── Register BouncyCastle security provider ────────────────────
        // Must be done before any crypto operation.
        java.security.Security.insertProviderAt(
                new org.bouncycastle.jce.provider.BouncyCastleProvider(), 1);

        setupDirectories();
    }

    public static NaveenApplication getInstance() {
        return sInstance;
    }

    /**
     * Mirror of Python setup_directories() — creates all working folders
     * under /storage/emulated/0/NaveenRx100/ .
     */
    private void setupDirectories() {
        // Primary root: /storage/emulated/0/NaveenRx100
        APP_ROOT        = new File("/storage/emulated/0/NaveenRx100");

        SOURCE_DIR      = new File(APP_ROOT, "SOURCE");
        REAL_DIR        = new File(APP_ROOT, "LUA_ORIGINAL");
        EDIT_DIR        = new File(APP_ROOT, "COMPILED");
        UNPACK_DIR      = new File(APP_ROOT, "LUA_EDIT");
        PAK_DIR         = new File(APP_ROOT, "PAK_ORIGINAL");
        PAK_UNPACK_DIR  = new File(APP_ROOT, "PAK_UNPACK");
        RESULT_DIR      = new File(APP_ROOT, "PAK_RESULT");
        BACKUP_DIR      = new File(APP_ROOT, "BACKUP");

        // PAK-Tool UI convention directories
        PAK_TOOL_DIR    = new File(APP_ROOT, "PAK TOOL");
        PAK_TOOL_PAK    = new File(PAK_TOOL_DIR, "PAK");
        PAK_TOOL_UNPACK = new File(PAK_TOOL_DIR, "UNPACK");
        PAK_TOOL_RESULT = new File(PAK_TOOL_DIR, "RESULT");

        File[] dirs = {
            APP_ROOT, SOURCE_DIR, REAL_DIR, EDIT_DIR, UNPACK_DIR,
            PAK_DIR, PAK_UNPACK_DIR, RESULT_DIR, BACKUP_DIR,
            PAK_TOOL_DIR, PAK_TOOL_PAK, PAK_TOOL_UNPACK, PAK_TOOL_RESULT
        };

        for (File d : dirs) {
            if (!d.exists()) {
                //noinspection ResultOfMethodCallIgnored
                d.mkdirs();
            }
        }
    }
}
