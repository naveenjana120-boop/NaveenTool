package com.naveenrx100.paktool.ui.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.naveenrx100.paktool.NaveenApplication;
import com.naveenrx100.paktool.R;

/**
 * MainActivity — Home Dashboard.
 * Mirrors the Python main_menu() function.
 * CREDIT: @NaveenRx100
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Header info
        TextView versionTv = findViewById(R.id.tv_version);
        if (versionTv != null)
            versionTv.setText("v" + NaveenApplication.APP_VERSION + "  |  " + NaveenApplication.CREDIT);

        // Dashboard cards
        setupCard(R.id.card_pak_tools,  PakToolsActivity.class);
        setupCard(R.id.card_lua_tools,  LuaToolsActivity.class);
        setupCard(R.id.card_inject,     InjectActivity.class);
        setupCard(R.id.card_profile,    ProfileActivity.class);
    }

    private void setupCard(int cardId, Class<?> target) {
        CardView card = findViewById(cardId);
        if (card != null) card.setOnClickListener(v -> {
            startActivity(new Intent(this, target));
            overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
        });
    }
}
