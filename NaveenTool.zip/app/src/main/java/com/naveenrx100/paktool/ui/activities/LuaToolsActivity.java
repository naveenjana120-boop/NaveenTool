package com.naveenrx100.paktool.ui.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.naveenrx100.paktool.NaveenApplication;
import com.naveenrx100.paktool.R;
import com.naveenrx100.paktool.core.lua.LuaTools;
import com.naveenrx100.paktool.utils.FileUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * LuaToolsActivity — Lua Tools screen.
 *
 * CREDIT: @NaveenRx100
 *
 * Actions:
 *  • DECOMPILE  — LUA_ORIGINAL/ → LUA_EDIT/   (BGMI → .lua source)
 *  • RECOMPILE  — LUA_EDIT/     → COMPILED/   (.lua source → BGMI .luac)
 *  • Open Lua File in Script Editor (future)
 *  • Lua Viewer  (show bytecode info)
 */
public class LuaToolsActivity extends AppCompatActivity {

    private TextView    tvLog, tvStats;
    private ProgressBar progressBar;
    private ScrollView  scrollLog;
    private Button      btnDecompile, btnRecompile, btnOpenFile, btnLuaViewer;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler         uiHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lua_tools);

        tvLog        = findViewById(R.id.tv_log);
        tvStats      = findViewById(R.id.tv_stats);
        progressBar  = findViewById(R.id.progress_bar);
        scrollLog    = findViewById(R.id.scroll_log);
        btnDecompile = findViewById(R.id.btn_decompile);
        btnRecompile = findViewById(R.id.btn_recompile);
        btnOpenFile  = findViewById(R.id.btn_open_lua_file);
        btnLuaViewer = findViewById(R.id.btn_lua_viewer);

        refreshStats();

        btnDecompile.setOnClickListener(v -> doDecompile());
        btnRecompile.setOnClickListener(v -> doRecompile());
        btnOpenFile.setOnClickListener(v -> showToast("Open file in Script Editor — coming soon"));
        btnLuaViewer.setOnClickListener(v -> showToast("Lua Viewer — coming soon"));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }

    // ── Decompile ─────────────────────────────────────────────────────

    private void doDecompile() {
        File srcDir = NaveenApplication.REAL_DIR;
        File[] files = srcDir.listFiles(f -> f.isFile() &&
                (f.getName().endsWith(".luac") || f.getName().endsWith(".lua")
                 || f.getName().endsWith(".slua")));

        if (files == null || files.length == 0) {
            showToast("LUA_ORIGINAL is empty. Put .luac files there first.");
            appendLog("⚠ LUA_ORIGINAL is empty!");
            return;
        }

        appendLog("Starting decompilation of " + files.length + " file(s)…");
        showProgress(true);
        setBtnsEnabled(false);

        LuaTools.decompileAll(this, new LuaTools.Callback() {
            @Override
            public void onProgress(int current, int total, String filename) {
                uiHandler.post(() -> {
                    progressBar.setMax(total);
                    progressBar.setProgress(current);
                });
            }
            @Override
            public void onLog(String line) {
                uiHandler.post(() -> appendLog(line));
            }
            @Override
            public void onDone(int success, int failed) {
                uiHandler.post(() -> {
                    showProgress(false);
                    setBtnsEnabled(true);
                    refreshStats();
                    appendLog("── Decompile done: " + success + " ok, " + failed + " failed ──");
                    showToast("Decompile: " + success + " ok / " + failed + " failed");
                });
            }
        });
    }

    // ── Recompile ─────────────────────────────────────────────────────

    private void doRecompile() {
        File srcDir = NaveenApplication.UNPACK_DIR;
        File[] files = srcDir.listFiles(f -> f.isFile() && f.getName().endsWith(".lua"));

        if (files == null || files.length == 0) {
            showToast("LUA_EDIT is empty. Decompile first or put .lua files there.");
            appendLog("⚠ LUA_EDIT is empty!");
            return;
        }

        appendLog("Starting recompilation of " + files.length + " file(s)…");
        showProgress(true);
        setBtnsEnabled(false);

        LuaTools.recompileAll(this, new LuaTools.Callback() {
            @Override
            public void onProgress(int current, int total, String filename) {
                uiHandler.post(() -> {
                    progressBar.setMax(total);
                    progressBar.setProgress(current);
                });
            }
            @Override
            public void onLog(String line) {
                uiHandler.post(() -> appendLog(line));
            }
            @Override
            public void onDone(int success, int failed) {
                uiHandler.post(() -> {
                    showProgress(false);
                    setBtnsEnabled(true);
                    refreshStats();
                    appendLog("── Recompile done: " + success + " ok, " + failed + " failed ──");
                    showToast("Recompile: " + success + " ok / " + failed + " failed");
                });
            }
        });
    }

    // ── Stats banner ─────────────────────────────────────────────────

    private void refreshStats() {
        int origCount    = countFiles(NaveenApplication.REAL_DIR,   ".luac", ".lua", ".slua");
        int editCount    = countFiles(NaveenApplication.UNPACK_DIR, ".lua");
        int compiledCount= countFiles(NaveenApplication.EDIT_DIR,   ".lua", ".luac");
        tvStats.setText("LUA_ORIGINAL: " + origCount
                + "   LUA_EDIT: " + editCount
                + "   COMPILED: " + compiledCount);
    }

    private int countFiles(File dir, String... exts) {
        if (!dir.exists()) return 0;
        File[] f = dir.listFiles(file -> {
            if (!file.isFile()) return false;
            for (String ext : exts) if (file.getName().endsWith(ext)) return true;
            return false;
        });
        return f == null ? 0 : f.length;
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private void appendLog(String line) {
        String ts = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        tvLog.append("\n[" + ts + "] " + line);
        scrollLog.post(() -> scrollLog.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private void showProgress(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (!show) progressBar.setProgress(0);
    }

    private void setBtnsEnabled(boolean en) {
        btnDecompile.setEnabled(en);
        btnRecompile.setEnabled(en);
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
