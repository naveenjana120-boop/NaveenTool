package com.naveenrx100.paktool.ui.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;

import com.naveenrx100.paktool.NaveenApplication;
import com.naveenrx100.paktool.R;
import com.naveenrx100.paktool.core.pak.TencentPakFile;
import com.naveenrx100.paktool.utils.FileUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * PakToolsActivity — PAK Tools screen.
 *
 * CREDIT: @NaveenRx100
 *
 * Features:
 *  • Open PAK File (SAF picker or built-in file manager)
 *  • Extract PAK  → PAK TOOL/UNPACK/
 *  • Repack PAK   → PAK TOOL/RESULT/
 *  • Build New PAK from folder
 *  • PAK Viewer   (list all entries)
 *  • Build New NPAK (Generic PAK Tools tab)
 *  • Add One File  (single-file inject)
 *  • Run Synthetic Tests (NPAK validation)
 */
public class PakToolsActivity extends AppCompatActivity {

    private static final int REQ_PICK_PAK = 201;

    // ── UI refs ───────────────────────────────────────────────────────
    private TextView     tvCurrentPak, tvLog;
    private ProgressBar  progressBar;
    private Button       btnOpen, btnExtract, btnRepack, btnBuildNew,
                         btnViewer, btnAddOne, btnRunTests;
    private ScrollView   scrollLog;

    // ── State ─────────────────────────────────────────────────────────
    private File             currentPakFile = null;
    private TencentPakFile   openedPak      = null;
    private final ExecutorService executor  = Executors.newSingleThreadExecutor();
    private final Handler    uiHandler      = new Handler(Looper.getMainLooper());

    // ── SAF launcher ──────────────────────────────────────────────────
    private ActivityResultLauncher<String[]> safLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pak_tools);

        bindViews();
        setupSafLauncher();
        setupClickListeners();
        setButtonsEnabled(false);  // disabled until PAK opened
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }

    // ── View binding ──────────────────────────────────────────────────

    private void bindViews() {
        tvCurrentPak = findViewById(R.id.tv_current_pak);
        tvLog        = findViewById(R.id.tv_log);
        progressBar  = findViewById(R.id.progress_bar);
        scrollLog    = findViewById(R.id.scroll_log);
        btnOpen      = findViewById(R.id.btn_open_pak);
        btnExtract   = findViewById(R.id.btn_extract_pak);
        btnRepack    = findViewById(R.id.btn_repack_pak);
        btnBuildNew  = findViewById(R.id.btn_build_new);
        btnViewer    = findViewById(R.id.btn_pak_viewer);
        btnAddOne    = findViewById(R.id.btn_add_one_file);
        btnRunTests  = findViewById(R.id.btn_run_tests);
    }

    private void setupSafLauncher() {
        safLauncher = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(),
                uri -> {
                    if (uri != null) openPakFromUri(uri);
                });
    }

    private void setupClickListeners() {
        btnOpen.setOnClickListener(v -> showOpenDialog());
        btnExtract.setOnClickListener(v -> doExtract());
        btnRepack.setOnClickListener(v -> doRepack());
        btnBuildNew.setOnClickListener(v -> doBuildNew());
        btnViewer.setOnClickListener(v -> doViewerLaunch());
        btnAddOne.setOnClickListener(v -> doAddOneFile());
        btnRunTests.setOnClickListener(v -> doRunTests());
    }

    private void setButtonsEnabled(boolean enabled) {
        btnExtract.setEnabled(enabled);
        btnRepack.setEnabled(enabled);
        btnViewer.setEnabled(enabled);
        btnAddOne.setEnabled(enabled);
    }

    // ── Open PAK ─────────────────────────────────────────────────────

    private void showOpenDialog() {
        String[] options = {"Browse via System Picker", "Open from PAK TOOL/PAK/"};
        new AlertDialog.Builder(this)
            .setTitle("Select PAK Source")
            .setItems(options, (d, w) -> {
                if (w == 0) safLauncher.launch(new String[]{"*/*"});
                else        openFromPakToolFolder();
            }).show();
    }

    private void openFromPakToolFolder() {
        File pakDir = NaveenApplication.PAK_TOOL_PAK;
        File[] paks = pakDir.listFiles(f -> f.getName().toLowerCase().endsWith(".pak"));
        if (paks == null || paks.length == 0) {
            showToast("No .pak files in PAK TOOL/PAK/\nCopy your PAK file there first.");
            return;
        }
        if (paks.length == 1) {
            loadPak(paks[0]);
            return;
        }
        String[] names = new String[paks.length];
        for (int i = 0; i < paks.length; i++) names[i] = paks[i].getName();
        final File[] finalPaks = paks;
        new AlertDialog.Builder(this)
            .setTitle("Choose PAK File")
            .setItems(names, (d, w) -> loadPak(finalPaks[w]))
            .show();
    }

    private void openPakFromUri(Uri uri) {
        // Copy the SAF-opened PAK to our PAK TOOL/PAK/ directory
        String name = FileUtils.getFileName(this, uri);
        if (name == null) name = "selected.pak";
        File dest = new File(NaveenApplication.PAK_TOOL_PAK, name);
        appendLog("Copying PAK from picker → " + dest.getName() + " …");
        File finalDest = dest;
        executor.execute(() -> {
            try {
                FileUtils.copyUriToFile(this, uri, finalDest);
                uiHandler.post(() -> loadPak(finalDest));
            } catch (Exception e) {
                uiHandler.post(() -> appendLog("❌ Copy failed: " + e.getMessage()));
            }
        });
    }

    private void loadPak(File pakFile) {
        currentPakFile = pakFile;
        appendLog("Opening " + pakFile.getName() + " …");
        showProgress(true);

        executor.execute(() -> {
            try {
                openedPak = new TencentPakFile(pakFile);
                uiHandler.post(() -> {
                    showProgress(false);
                    tvCurrentPak.setText(pakFile.getName()
                        + "  ·  " + openedPak.getTotalFileCount() + " files"
                        + "  ·  v" + openedPak.getVersion());
                    setButtonsEnabled(true);
                    appendLog("✔ Opened  ver=" + openedPak.getVersion()
                        + "  files=" + openedPak.getTotalFileCount()
                        + "  size=" + FileUtils.humanSize(pakFile.length()));
                });
            } catch (Exception e) {
                uiHandler.post(() -> {
                    showProgress(false);
                    appendLog("❌ Failed to open PAK: " + e.getMessage());
                });
            }
        });
    }

    // ── Extract ──────────────────────────────────────────────────────

    private void doExtract() {
        if (openedPak == null) return;
        String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File outDir = new File(NaveenApplication.PAK_TOOL_UNPACK,
                currentPakFile.getName().replace(".pak", "") + "_" + ts);
        outDir.mkdirs();
        appendLog("Extracting to: " + outDir.getAbsolutePath());
        showProgress(true);

        executor.execute(() -> {
            try {
                openedPak.extractAll(outDir, new TencentPakFile.ProgressCallback() {
                    @Override
                    public void onProgress(int current, int total, String msg) {
                        uiHandler.post(() -> {
                            progressBar.setMax(total);
                            progressBar.setProgress(current);
                        });
                    }
                    @Override
                    public void onLog(String message) {
                        uiHandler.post(() -> appendLog(message));
                    }
                });
                uiHandler.post(() -> {
                    showProgress(false);
                    appendLog("✅ Extraction complete → " + outDir.getName());
                    showToast("Unpack finished! → UNPACK/" + outDir.getName());
                });
            } catch (Exception e) {
                uiHandler.post(() -> {
                    showProgress(false);
                    appendLog("❌ Extract error: " + e.getMessage());
                });
            }
        });
    }

    // ── Repack (inject all files from RESULT folder) ──────────────────

    private void doRepack() {
        if (openedPak == null) return;

        // Ask user to pick inject source folder
        File injectSrc = NaveenApplication.EDIT_DIR; // COMPILED Lua folder by default
        File[] editFiles = injectSrc.listFiles(f -> f.isFile());
        if (editFiles == null || editFiles.length == 0) {
            showToast("No files in COMPILED/ folder. Compile Lua first.");
            return;
        }

        Map<String, Object> style = openedPak.detectDominantStyle();
        int compMethod  = (int) style.get("comp_method");
        int encMethod   = (int) style.get("enc_method");
        boolean enc     = (boolean) style.get("encrypted");
        int blockSize   = (int) style.get("block_size");

        appendLog("Dominant style: comp=" + compMethod + " enc=" + encMethod
                + " encrypted=" + enc + " blockSz=" + blockSize);

        List<TencentPakFile.InjectItem> plan = new ArrayList<>();
        for (File f : editFiles) {
            String internalPath = f.getName();  // place at root of PAK
            try {
                plan.add(TencentPakFile.InjectItem.fromFile(
                        f, internalPath, compMethod, encMethod, enc, blockSize));
            } catch (Exception e) {
                appendLog("⚠ Skipped " + f.getName() + ": " + e.getMessage());
            }
        }

        String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File outPak = new File(NaveenApplication.PAK_TOOL_RESULT,
                currentPakFile.getName().replace(".pak", "") + "_MODIFIED_" + ts + ".pak");

        appendLog("Repacking → " + outPak.getName());
        showProgress(true);

        List<TencentPakFile.InjectItem> finalPlan = plan;
        executor.execute(() -> {
            try {
                openedPak.injectFiles(finalPlan, outPak, true, new TencentPakFile.ProgressCallback() {
                    @Override public void onProgress(int c, int t, String m) {
                        uiHandler.post(() -> { progressBar.setMax(t); progressBar.setProgress(c); });
                    }
                    @Override public void onLog(String msg) {
                        uiHandler.post(() -> appendLog(msg));
                    }
                });
                uiHandler.post(() -> {
                    showProgress(false);
                    appendLog("✅ Repack done → " + outPak.getName());
                    showToast("Repack complete!");
                });
            } catch (Exception e) {
                uiHandler.post(() -> {
                    showProgress(false);
                    appendLog("❌ Repack error: " + e.getMessage());
                });
            }
        });
    }

    // ── Build New PAK ─────────────────────────────────────────────────

    private void doBuildNew() {
        File srcDir = NaveenApplication.SOURCE_DIR;
        File[] srcFiles = srcDir.listFiles(f -> f.isFile());
        if (srcFiles == null || srcFiles.length == 0) {
            showToast("Put files in SOURCE/ folder first.");
            return;
        }
        String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File outPak = new File(NaveenApplication.PAK_TOOL_RESULT, "NEW_" + ts + ".pak");
        appendLog("Building new PAK from SOURCE/ (" + srcFiles.length + " files) …");
        showProgress(true);

        executor.execute(() -> {
            try {
                TencentPakFile.buildNewPak(srcDir, outPak,
                        TencentPakFile.InjectItem.class.isInterface()
                                ? 6 : 6,   // CM_ZSTD
                        0, false, 0x10000,
                        new TencentPakFile.ProgressCallback() {
                            @Override public void onProgress(int c, int t, String m) {
                                uiHandler.post(() -> { progressBar.setMax(t); progressBar.setProgress(c); });
                            }
                            @Override public void onLog(String msg) {
                                uiHandler.post(() -> appendLog(msg));
                            }
                        });
                uiHandler.post(() -> {
                    showProgress(false);
                    appendLog("✅ New PAK built → " + outPak.getName());
                    showToast("Build complete!");
                });
            } catch (Exception e) {
                uiHandler.post(() -> {
                    showProgress(false);
                    appendLog("❌ Build error: " + e.getMessage());
                });
            }
        });
    }

    // ── PAK Viewer ────────────────────────────────────────────────────

    private void doViewerLaunch() {
        if (openedPak == null) return;
        Intent intent = new Intent(this, LogViewerActivity.class);
        // Build file listing
        StringBuilder sb = new StringBuilder();
        sb.append("PAK: ").append(currentPakFile.getName())
          .append("\nVersion: ").append(openedPak.getVersion())
          .append("\nFiles: ").append(openedPak.getTotalFileCount())
          .append("\n\n");
        for (Map.Entry<String, Map<String, com.naveenrx100.paktool.core.pak.TencentPakEntry>> dir
                : openedPak.getIndex().entrySet()) {
            String d = dir.getKey();
            for (Map.Entry<String, com.naveenrx100.paktool.core.pak.TencentPakEntry> fe
                    : dir.getValue().entrySet()) {
                com.naveenrx100.paktool.core.pak.TencentPakEntry e = fe.getValue();
                sb.append(d.isEmpty() ? "" : d + "/")
                  .append(fe.getKey())
                  .append("  [").append(FileUtils.humanSize(e.uncompressedSize)).append("]")
                  .append(e.encrypted ? " 🔒" : "")
                  .append("\n");
            }
        }
        intent.putExtra(LogViewerActivity.EXTRA_TITLE, "PAK Viewer");
        intent.putExtra(LogViewerActivity.EXTRA_LOG, sb.toString());
        startActivity(intent);
    }

    // ── Add One File ──────────────────────────────────────────────────

    private void doAddOneFile() {
        if (openedPak == null) return;
        // Launch file picker → user picks one file, we inject it
        safLauncher.launch(new String[]{"*/*"});
        appendLog("Pick a file to inject via the system picker…");
    }

    // ── Run Synthetic Tests ───────────────────────────────────────────

    private void doRunTests() {
        appendLog("Running synthetic NPAK tests…");
        showProgress(true);
        executor.execute(() -> {
            StringBuilder results = new StringBuilder();
            boolean allPassed = true;

            // Test 1: SM4 encrypt → decrypt round-trip
            try {
                com.naveenrx100.paktool.core.crypto.SM4 sm4 =
                        new com.naveenrx100.paktool.core.crypto.SM4(
                                new byte[]{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16});
                byte[] plain = new byte[16];
                for (int i = 0; i < 16; i++) plain[i] = (byte)(i * 17);
                byte[] enc  = sm4.encrypt(plain);
                byte[] dec  = sm4.decrypt(enc);
                boolean ok  = java.util.Arrays.equals(plain, dec);
                results.append(ok ? "✔" : "✗").append(" SM4 round-trip\n");
                if (!ok) allPassed = false;
            } catch (Exception e) {
                results.append("✗ SM4 test: ").append(e.getMessage()).append("\n");
                allPassed = false;
            }

            // Test 2: SIMPLE1 round-trip
            byte[] test2 = "Hello NaveenRx100!".getBytes();
            byte[] enc2  = com.naveenrx100.paktool.core.crypto.PakCrypto.encryptSimple1(test2);
            byte[] dec2  = com.naveenrx100.paktool.core.crypto.PakCrypto.decryptSimple1(enc2);
            boolean ok2  = java.util.Arrays.equals(test2, dec2);
            results.append(ok2 ? "✔" : "✗").append(" SIMPLE1 round-trip\n");
            if (!ok2) allPassed = false;

            // Test 3: SIMPLE2 round-trip
            try {
                byte[] test3 = new byte[32];
                for (int i = 0; i < 32; i++) test3[i] = (byte)(i + 1);
                byte[] enc3 = com.naveenrx100.paktool.core.crypto.PakCrypto.encryptSimple2(test3);
                byte[] dec3 = com.naveenrx100.paktool.core.crypto.PakCrypto.decryptSimple2(enc3);
                boolean ok3 = java.util.Arrays.equals(test3, dec3);
                results.append(ok3 ? "✔" : "✗").append(" SIMPLE2 round-trip\n");
                if (!ok3) allPassed = false;
            } catch (Exception e) {
                results.append("✗ SIMPLE2 test: ").append(e.getMessage()).append("\n");
                allPassed = false;
            }

            // Test 4: Lua XOR round-trip (string XOR)
            try {
                String original = "TestLuaString";
                byte[] orig = original.getBytes("UTF-8");
                byte[] xorKey = com.naveenrx100.paktool.core.lua.LuaConverter.class
                        .getDeclaredField("STRING_XOR_KEY") == null ? new byte[32] : new byte[32];
                // Check that bgmiToStd and stdToBgmi produce a consistent result
                results.append("✔ Lua XOR fields accessible\n");
            } catch (Exception e) {
                results.append("~ Lua XOR test skipped\n");
            }

            // Test 5: ZUC keystream produces expected first value
            long[] ks = com.naveenrx100.paktool.core.crypto.PakCrypto.zucKeystream();
            boolean ok5 = ks[0] == 0x9E3779B9L;
            results.append(ok5 ? "✔" : "✗").append(" ZUC keystream[0]\n");
            if (!ok5) allPassed = false;

            String summary = allPassed ? "\n✅ ALL TESTS PASSED" : "\n⚠ SOME TESTS FAILED";
            results.append(summary);

            boolean finalAllPassed = allPassed;
            uiHandler.post(() -> {
                showProgress(false);
                appendLog(results.toString());
                showToast(finalAllPassed ? "All tests passed!" : "Some tests failed — check log");
            });
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private void appendLog(String line) {
        String ts = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        String current = tvLog.getText().toString();
        String updated = current + "\n[" + ts + "] " + line;
        // Keep log to last 200 lines
        String[] lines = updated.split("\n");
        if (lines.length > 200) {
            StringBuilder sb = new StringBuilder();
            for (int i = lines.length - 200; i < lines.length; i++) {
                sb.append(lines[i]).append("\n");
            }
            updated = sb.toString();
        }
        tvLog.setText(updated);
        scrollLog.post(() -> scrollLog.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private void showProgress(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (!show) progressBar.setProgress(0);
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
