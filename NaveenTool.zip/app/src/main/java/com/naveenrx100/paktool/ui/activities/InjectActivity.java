package com.naveenrx100.paktool.ui.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.naveenrx100.paktool.NaveenApplication;
import com.naveenrx100.paktool.R;
import com.naveenrx100.paktool.core.pak.TencentPakFile;
import com.naveenrx100.paktool.utils.FileUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * InjectActivity — Inject Tool screen.
 *
 * CREDIT: @NaveenRx100
 *
 * Mirrors Python action_inject_lua():
 *  1. Reads compiled Lua files from COMPILED/
 *  2. Reads original PAK from PAK_ORIGINAL/
 *  3. Detects dominant PAK style
 *  4. Injects COMPILED files at their matching internal paths
 *  5. Writes modified PAK to PAK_RESULT/
 *
 * Also:
 *  • Select Process  (placeholder — game process injection)
 *  • Inject Script   (inject into running process via shell)
 *  • Manage Injection
 *  • Clear Injection
 */
public class InjectActivity extends AppCompatActivity {

    private TextView    tvLog, tvStatus;
    private ProgressBar progressBar;
    private ScrollView  scrollLog;
    private Button      btnSelectProcess, btnInjectScript,
                        btnManageInject, btnClearInject, btnInjectPak;

    private final ExecutorService executor  = Executors.newSingleThreadExecutor();
    private final Handler         uiHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inject);

        tvLog           = findViewById(R.id.tv_log);
        tvStatus        = findViewById(R.id.tv_status);
        progressBar     = findViewById(R.id.progress_bar);
        scrollLog       = findViewById(R.id.scroll_log);
        btnSelectProcess= findViewById(R.id.btn_select_process);
        btnInjectScript = findViewById(R.id.btn_inject_script);
        btnManageInject = findViewById(R.id.btn_manage_injection);
        btnClearInject  = findViewById(R.id.btn_clear_injection);
        btnInjectPak    = findViewById(R.id.btn_inject_pak);

        btnSelectProcess.setOnClickListener(v -> showToast("Select Process — requires root/ADB"));
        btnInjectScript.setOnClickListener(v -> showToast("Inject Script — requires root/ADB"));
        btnManageInject.setOnClickListener(v -> showToast("Manage Injection — requires root/ADB"));
        btnClearInject.setOnClickListener(v -> showToast("Clear Injection — requires root/ADB"));
        btnInjectPak.setOnClickListener(v -> doInjectPak());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }

    // ── Main Inject Flow ──────────────────────────────────────────────

    private void doInjectPak() {
        // 1. Find compiled Lua files
        File compiledDir = NaveenApplication.EDIT_DIR;
        File[] compiled  = compiledDir.listFiles(f -> f.isFile() &&
                (f.getName().endsWith(".lua") || f.getName().endsWith(".luac")));
        if (compiled == null || compiled.length == 0) {
            showToast("COMPILED/ folder is empty. Compile Lua files first.");
            return;
        }

        // 2. Find PAK file in PAK_ORIGINAL/
        File pakOrigDir = NaveenApplication.PAK_DIR;
        File[] paks = pakOrigDir.listFiles(f -> f.getName().toLowerCase().endsWith(".pak"));
        if (paks == null || paks.length == 0) {
            showToast("No PAK in PAK_ORIGINAL/. Put your .pak file there.");
            return;
        }

        if (paks.length == 1) {
            startInject(paks[0], compiled);
        } else {
            String[] names = new String[paks.length];
            for (int i = 0; i < paks.length; i++) names[i] = paks[i].getName();
            File[] finalPaks = paks;
            File[] finalCompiled = compiled;
            new AlertDialog.Builder(this)
                .setTitle("Select PAK to inject into")
                .setItems(names, (d, w) -> startInject(finalPaks[w], finalCompiled))
                .show();
        }
    }

    private void startInject(File pakFile, File[] compiledFiles) {
        appendLog("Source PAK: " + pakFile.getName());
        appendLog("Inject files: " + compiledFiles.length);
        showProgress(true);
        btnInjectPak.setEnabled(false);

        // Backup first
        File backupDir = NaveenApplication.BACKUP_DIR;
        String ts      = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File backup    = new File(backupDir, pakFile.getName().replace(".pak","") + "_backup_" + ts + ".pak");

        executor.execute(() -> {
            try {
                // Backup
                FileUtils.copyFile(pakFile, backup);
                uiHandler.post(() -> appendLog("✔ Backup → " + backup.getName()));

                // Open PAK
                uiHandler.post(() -> appendLog("Loading PAK…"));
                TencentPakFile pak = new TencentPakFile(pakFile);

                // Detect dominant style
                Map<String, Object> style = pak.detectDominantStyle();
                int compMethod = (int) style.get("comp_method");
                int encMethod  = (int) style.get("enc_method");
                boolean enc    = (boolean) style.get("encrypted");
                int blockSize  = (int) style.get("block_size");

                uiHandler.post(() -> appendLog(
                    "Style: comp=" + compMethod + " enc=" + encMethod
                    + " encrypted=" + enc + " block=" + blockSize));

                // Build inject plan
                // Try to match each compiled file to an existing PAK entry path
                List<TencentPakFile.InjectItem> plan = new ArrayList<>();
                for (File f : compiledFiles) {
                    String internalPath = resolveInternalPath(pak, f.getName());
                    uiHandler.post(() -> appendLog("  " + f.getName() + " → " + internalPath));
                    plan.add(TencentPakFile.InjectItem.fromFile(
                            f, internalPath, compMethod, encMethod, enc, blockSize));
                }

                // Output path
                File outDir = NaveenApplication.RESULT_DIR;
                outDir.mkdirs();
                File outPak = new File(outDir,
                        pakFile.getName().replace(".pak", "") + "_MODIFIED_" + ts + ".pak");

                // Inject
                pak.injectFiles(plan, outPak, true, new TencentPakFile.ProgressCallback() {
                    @Override public void onProgress(int c, int t, String m) {
                        uiHandler.post(() -> { progressBar.setMax(t); progressBar.setProgress(c); });
                    }
                    @Override public void onLog(String msg) {
                        uiHandler.post(() -> appendLog(msg));
                    }
                });

                uiHandler.post(() -> {
                    showProgress(false);
                    btnInjectPak.setEnabled(true);
                    appendLog("✅ Injection complete → " + outPak.getName());
                    tvStatus.setText("✅ Done: " + outPak.getName());
                    showToast("Inject complete! Output: PAK_RESULT/" + outPak.getName());
                });

            } catch (Exception e) {
                uiHandler.post(() -> {
                    showProgress(false);
                    btnInjectPak.setEnabled(true);
                    appendLog("❌ Inject error: " + e.getMessage());
                    showToast("Inject failed: " + e.getMessage());
                });
            }
        });
    }

    /**
     * Tries to find where a compiled file belongs inside the PAK.
     * Searches the PAK index for a matching filename.
     * Falls back to placing the file at root if not found.
     */
    private String resolveInternalPath(TencentPakFile pak, String filename) {
        String nameLower = filename.toLowerCase();
        // Strip compiled extension variants to find base name
        String base = nameLower;
        if (base.endsWith(".lua"))  base = base.substring(0, base.length() - 4);
        if (base.endsWith(".luac")) base = base.substring(0, base.length() - 5);

        for (Map.Entry<String, Map<String, com.naveenrx100.paktool.core.pak.TencentPakEntry>> dir
                : pak.getIndex().entrySet()) {
            for (String fname : dir.getValue().keySet()) {
                String fl = fname.toLowerCase();
                String fb = fl.endsWith(".luac") ? fl.substring(0, fl.length() - 5)
                          : fl.endsWith(".lua")  ? fl.substring(0, fl.length() - 4) : fl;
                if (fb.equals(base)) {
                    String d = dir.getKey();
                    return (d.isEmpty() || d.equals(".")) ? fname
                           : d.replaceAll("/$", "") + "/" + fname;
                }
            }
        }
        return filename; // fallback: root of PAK
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private void appendLog(String line) {
        String ts = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        tvLog.append("\n[" + ts + "] " + line);
        scrollLog.post(() -> scrollLog.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private void showProgress(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (!show) progressBar.setProgress(0);
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
